# MoveAble — Smart Wheelchair Conversion Kit

A responsive, single-page website for a student innovation project.

## Files
- `index.html` — complete website (HTML, CSS, and JavaScript in one file)
- `README.md` — these instructions

## Preview locally
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create a new **public** repository on GitHub (for example, `moveable-wheelchair`).
2. Upload `index.html` and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then click **Save**.
6. Wait for the Pages URL to appear in the Pages settings.

## Before submitting
- Confirm team names and descriptions.
- Add your own prototype photographs/video if available.
- Replace any text that does not exactly match your prototype.
- Keep the distinction between the existing IR-sensor prototype and planned features.
- Test all real hardware safely before making performance claims.

The site is an informational project showcase, not a claim that every planned feature is already built or certified for real-world use.
